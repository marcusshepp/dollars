from django.contrib import admin

from .models import Pic

admin.site.register(Pic)
